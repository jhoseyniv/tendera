'use client';

export default function UsersPage() {

  return (

    <div>

      <h1>
        Users
      </h1>

      <p>
        Users Management Page
      </p>

    </div>
  );
}