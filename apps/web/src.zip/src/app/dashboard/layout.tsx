'use client';

import Sidebar
from '@/layout/sidebar/Sidebar';

export default function DashboardLayout({
  children
}: {
  children: React.ReactNode
}) {

  return (

    <div
      style={{
        display: 'flex'
      }}
    >

      <Sidebar />

      <div
        style={{
          flex: 1,
          padding: '20px'
        }}
      >

        {children}

      </div>

    </div>
  );
}