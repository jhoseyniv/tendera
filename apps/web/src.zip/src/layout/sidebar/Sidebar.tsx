'use client';

import {
  useEffect,
  useState
} from 'react';

import axios from 'axios';

import Link from 'next/link';

interface PageItem {

  page_code: string;

  page_name: string;

  route_path: string;
}

export default function Sidebar() {

  const [pages, setPages] =
    useState<PageItem[]>([]);

  useEffect(() => {

    const loadPages =
      async () => {

      const user =
        JSON.parse(
          localStorage.getItem('user')
          || '{}'
        );

      const res =
        await axios.get(

`http://localhost:3001/me/pages?email=${user.email}`

        );

      setPages(res.data);
    };

    loadPages();

  }, []);

  return (

    <div
      style={{

        width: '250px',

        height: '100vh',

        background: '#111827',

        color: 'white',

        padding: '20px'
      }}
    >

      <h2>
        Tendera AI
      </h2>

      <ul
        style={{
          listStyle: 'none',
          padding: 0
        }}
      >

        {pages.map((p) => (

          <li
            key={p.page_code}
            style={{
              marginBottom: '12px'
            }}
          >

            <Link
              href={p.route_path}

              style={{
                color: 'white',
                textDecoration: 'none'
              }}
            >

              {p.page_name}

            </Link>

          </li>
        ))}

      </ul>

    </div>
  );
}